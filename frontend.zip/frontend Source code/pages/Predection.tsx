import React, { useState, useEffect } from "react";
import Modal from "react-modal"; // Import react-modal
import { Send2 } from "iconsax-react";

interface Item {
  question: string;
  answer: string;
}

const Predection = () => {
  const [hours, setHours] = useState("");
  const [loading, setLoading] = useState(false);
  const [score, setScore] = useState<number>(0);
  const [items, setItems] = useState<Item[]>([]);
  const [message, setMessage] = useState("");
  const [pdfFile, setPdfFile] = useState<File | null>(null); // State for the PDF file
  const [pdfUrl, setPdfUrl] = useState('');
  const [modalIsOpen, setModalIsOpen] = useState(false); // State for modal visibility
  const [studyStartTime, setStudyStartTime] = useState<Date | null>(null);
  const [studyEndTime, setStudyEndTime] = useState<Date | null>(null);

  // Track study time when the modal is open
  useEffect(() => {
    if (modalIsOpen && studyStartTime === null) {
      setStudyStartTime(new Date()); // Start tracking study time when PDF opens
    } else if (!modalIsOpen && studyStartTime) {
      setStudyEndTime(new Date()); // Track the end time when the PDF is closed
    }
  }, [modalIsOpen]);

  const calculateStudyTime = () => {
    if (studyStartTime && studyEndTime) {
      const timeDifference = Math.abs(studyEndTime.getTime() - studyStartTime.getTime()) / (1000 * 60 * 60); // Convert milliseconds to hours
      return timeDifference.toFixed(2); // Return the study time in hours (rounded to two decimal places)
    }
    return "0";
  };

  const predict = async () => {
    const studyTime = calculateStudyTime();

    const response = await fetch("http://localhost:5000/predict", {
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
      method: "POST",
      body: JSON.stringify({
        study_hours: studyTime,
      }),
    });

    const data = await response.json();
    if (!response.ok) {
      alert(data.msg);
    } else {
      const newItem: Item = {
        question: `Your average score: ${data.predicted_score}`,
        answer: `${studyTime} hours`,
      };
      setItems([...items, newItem]);
      setLoading(false);
      setScore(data.predicted_score);
    }
  };

  return (
    <div className="w-[100vw] h-[100vh] bg-[#000000]">
      <h1 className="text-center text-[50px] text-[#ffff] pt-[20px]">
        Study Analysis Tool
      </h1>
      <p className="text-[#fff] text-center">
        Upload your study material (PDF) and track your study time.
      </p>
      
      <div className="flex justify-center pt-[20px]">
        <div className="bg-[#111111] relative rounded-lg w-[600px] p-[50px] h-[600px]">
          <div className="overflow-y-scroll h-[400px]">
            {items.map((item, index) => (
              <div className="mt-5" key={index}>
                <div className="flex justify-end mt-5">
                  <div className="bg-[#ddd] text-[#111111] w-[fit-content] px-5 py-2 rounded-br-none rounded-lg">
                    {item.answer}
                  </div>
                </div>
                <div className="bg-[#ddd] mt-5 text-[#111111] w-[fit-content] px-5 py-2 rounded-bl-none rounded-lg">
                  {loading ? (
                    <svg
                      aria-hidden="true"
                      className="w-5 h-5 text-gray-200 animate-spin dark:text-gray-600 fill-white"
                      viewBox="0 0 100 101"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                        fill="currentColor"
                      />
                      <path
                        d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                        fill="currentFill"
                      />
                    </svg>
                  ) : (
                    item.question
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="absolute bottom-10 left-0 right-0">
            <div className="flex items-center justify-between rounded-md bg-[#fff] mx-10 p-2">
              <input
                type="file"
                accept="application/pdf"
                onChange={(e) => {
                  const file = e.target.files[0];
                  if (file) {
                    const url = URL.createObjectURL(file);
                    setPdfUrl(url);
                    setPdfFile(file);
                  }
                }}
                className="mb-3"
              />
              {pdfUrl && (
                <button
                  className="bg-[#000] text-white p-2 rounded-lg cursor-pointer w-128"
                  onClick={() => setModalIsOpen(true)} // Open modal
                >
                  Start Studying
                </button>
              )}
              <div
                className="bg-[#000] p-2 rounded-lg cursor-pointer"
                onClick={() => {
                  predict();
                }}
              >
                <Send2 color="#fff" size={20} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal for PDF Viewer */}
      <Modal
        isOpen={modalIsOpen}
        onRequestClose={() => setModalIsOpen(false)}
        contentLabel="PDF Viewer"
        className="modal w-full max-w-4xl mx-auto mt-10"
        overlayClassName="fixed inset-0 bg-black bg-opacity-50"
      >
        <div className="relative p-4 bg-white rounded-lg">
          <button
            className="absolute top-2 right-2 bg-red-600 text-white p-2 rounded-full"
            onClick={() => setModalIsOpen(false)} // Close modal
          >
            X
          </button>
          <h2 className="text-xl font-bold mb-4">PDF Viewer</h2>
          <iframe
            src={pdfUrl}
            width="100%"
            height="600"
            className="border-0"
            title="PDF Viewer"
          ></iframe>
          <p className="mt-4">Study Time: {calculateStudyTime()} hours</p>
        </div>
      </Modal>
    </div>
  );
};

export default Predection;
