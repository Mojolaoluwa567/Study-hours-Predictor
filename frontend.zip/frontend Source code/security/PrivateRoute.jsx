import React, { useEffect } from "react";
import { Navigate, Outlet } from "react-router-dom";
const PrivateRoute = () => {
  const token = localStorage.getItem("token");
  const auth = { isAuthenticated: false };
  token ? auth.isAuthenticated = true : auth.isAuthenticated = false
  return(
    auth.isAuthenticated ? <Outlet /> : <Navigate to={"/"} />
  );
};

export default PrivateRoute;
