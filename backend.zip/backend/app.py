from flask import Flask, request, jsonify, session
from flask_bcrypt import Bcrypt
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, jwt_required, create_access_token, get_jwt_identity
import logging
import re
from predict_scores import model
import math

app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'

# Replace with your MySQL database URL without a password
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root@localhost/testDB'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
jwt = JWTManager(app)
CORS(app, supports_credentials=True)

# Configure logging
logging.basicConfig(level=logging.INFO)


# Define your User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), nullable=False, unique=True)
    password = db.Column(db.String(150), nullable=False)
    predicted_score = db.Column(db.Float, nullable=True)


# Create tables if they do not exist
# @app.before_first_request
# def create_tables():
#     db.create_all()


# Function to extract study hours from a sentence
def extract_study_hours(sentence):
    match = re.search(r'(\d+)', sentence)
    if match:
        hours = int(match.group(1))
        return hours
    return None


# Signup endpoint
@app.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify(error="Username and password are required"), 400

    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    new_user = User(username=username, password=hashed_password)
    try:
        db.session.add(new_user)
        db.session.commit()
        return jsonify(message="User created successfully")
    except Exception as e:
        db.session.rollback()
        error_msg = f"Failed to create user: {str(e)}"
        logging.error(error_msg)
        return jsonify(error=error_msg), 500


# Login endpoint
@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify(error="Username and password are required"), 400

    user = User.query.filter_by(username=username).first()
    if user and bcrypt.check_password_hash(user.password, password):
        access_token = create_access_token(identity=user.id)
        session['user_id'] = user.id
        return jsonify(message="Login successful", access_token=access_token)
    return jsonify(error="Invalid credentials"), 401


# Logout endpoint
@app.route('/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)
    return jsonify(message="Logged out")


# Profile endpoint
@app.route('/profile', methods=['GET'])
@jwt_required()
def profile():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user:
        return jsonify(error="User not found"), 404
    return jsonify(username=user.username, predicted_score=user.predicted_score)


# Predict endpoint
@app.route('/predict', methods=['POST'])
@jwt_required()
def predict():
    data = request.get_json()
    study_hours_sentence = data.get('study_hours')

    if not study_hours_sentence:
        return jsonify(error="Study hours sentence is required"), 400

    study_hours = extract_study_hours(study_hours_sentence)
    if study_hours is None:
        return jsonify(error="Could not extract study hours from the sentence"), 400

    # Limit study hours to a maximum of 10
    if study_hours > 10:
        study_hours = 10

    predicted_score = model.predict([[study_hours]])[0]  # Assuming model.predict returns a float
    user_id = get_jwt_identity()
    user = User.query.get(user_id)

    if not user:
        return jsonify(error="User not found"), 404

    # Convert predicted_score to float if necessary
    predicted_score = float(predicted_score)
    user.predicted_score = predicted_score
    db.session.commit()
    total_score = 119
    score_in_percentage = str(math.floor((predicted_score / total_score) * 100)) + "%"
    return jsonify(predicted_score=score_in_percentage)



if __name__ == '__main__':
    app.run(debug=True)

