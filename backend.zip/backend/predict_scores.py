# Import necessary libraries
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import re

print("Starting script...")

# Load the dataset
df = pd.read_csv('/exam-score-predictor/synthetic_student_scores.csv')

# Print the columns of the DataFrame to debug
print("Columns in the dataset:", df.columns)

# Ensure column names are stripped of any leading/trailing spaces
df.columns = df.columns.str.strip()

# Display the first few rows of the dataset to understand its structure
print("Dataset Preview:")
print(df.head())

# Split the data into features (X) and target (y)
X = df[['Study Hours']]  # Feature (study hours)
y = df['Exam Score']     # Target (exam scores)

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Print the sizes of the training and testing sets
print(f"Training set size: {len(X_train)}, Testing set size: {len(X_test)}")

# Create a linear regression model
model = LinearRegression()

# Train the model using the training data
model.fit(X_train, y_train)

# Predict the scores using the testing data
y_pred = model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

# Print the model's performance metrics
print(f"Mean Squared Error: {mse}")
print(f"R^2 Score: {r2}")

# Cross-validation
kf = KFold(n_splits=5, shuffle=True, random_state=42)
cv_mse_scores = cross_val_score(model, X, y, cv=kf, scoring='neg_mean_squared_error')
cv_r2_scores = cross_val_score(model, X, y, cv=kf, scoring='r2')

print(f"Cross-Validation Mean Squared Error: {-np.mean(cv_mse_scores)}")
print(f"Cross-Validation R^2 Score: {np.mean(cv_r2_scores)}")
print(np.max(y), "Total")
# Function to extract study hours from a sentence
def extract_study_hours(sentence):
    # Regular expression to find numbers in the sentence
    match = re.search(r'(\d+)', sentence)
    if match:
        # Convert the found number to an integer
        hours = int(match.group(1))
        return hours
    return None

# Example sentence
sentence = "I study for 7 hours daily"
study_hours = extract_study_hours(sentence)

if study_hours is not None:
    hours = pd.DataFrame({'Study Hours': [study_hours]})  # Create a DataFrame with the extracted study hours
    predicted_score = model.predict(hours)
    print(f"Predicted score for {study_hours} hours of study: {predicted_score[0]}")
else:
    print("No study hours found in the sentence.")
